package chess;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class ChessPieceTest {

    @Test
    public void testPawnMoves() {
        ChessPiece pawn = new Pawn();
        List<String> moves = pawn.getValidMoves("G1");
        assertEquals(List.of("G2"), moves);
        assertTrue(pawn.getValidMoves("H8").isEmpty());
    }

    @Test
    public void testKingMoves() {
        ChessPiece king = new King();
        List<String> moves = king.getValidMoves("D5");
        assertEquals(8, moves.size());
        assertTrue(moves.contains("C4"));
    }

    @Test
    public void testQueenMoves() {
        ChessPiece queen = new Queen();
        List<String> moves = queen.getValidMoves("E4");
        assertTrue(moves.contains("A4"));
        assertTrue(moves.contains("E8"));
        assertTrue(moves.contains("H1"));
    }
}