package chess;

public class Position {
    public int row;
    public int col;

    public Position(int row, int col) {
        this.row = row;
        this.col = col;
    }

    public static Position fromString(String pos) {
        int col = pos.charAt(0) - 'A';
        int row = Character.getNumericValue(pos.charAt(1)) - 1;
        return new Position(row, col);
    }

    public static boolean isValid(int row, int col) {
        return row >= 0 && row < 8 && col >= 0 && col < 8;
    }

    public String toString() {
        return "" + (char) (col + 'A') + (row + 1);
    }
}