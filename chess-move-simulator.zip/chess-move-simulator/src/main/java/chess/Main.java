package chess;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter piece and position (e.g., King, D5): ");
        String input = scanner.nextLine();
        scanner.close();

        String[] parts = input.split(",");
        if (parts.length != 2) {
            System.out.println("Invalid input. Format: <Piece>, <Position>");
            return;
        }

        String pieceType = parts[0].trim().toLowerCase();
        String position = parts[1].trim().toUpperCase();

        ChessPiece piece;
        switch (pieceType) {
            case "pawn":
                piece = new Pawn();
                break;
            case "king":
                piece = new King();
                break;
            case "queen":
                piece = new Queen();
                break;
            default:
                System.out.println("Unsupported piece type.");
                return;
        }

        List<String> moves = piece.getValidMoves(position);
        if (moves.isEmpty()) {
            System.out.println("No valid moves.");
        } else {
            System.out.println(String.join(", ", moves));
        }
    }
}