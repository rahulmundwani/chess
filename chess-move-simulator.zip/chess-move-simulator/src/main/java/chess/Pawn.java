package chess;

import java.util.ArrayList;
import java.util.List;

public class Pawn implements ChessPiece {
    public List<String> getValidMoves(String posStr) {
        Position pos = Position.fromString(posStr);
        List<String> moves = new ArrayList<>();
        int newRow = pos.row + 1;
        if (Position.isValid(newRow, pos.col)) {
            moves.add(new Position(newRow, pos.col).toString());
        }
        return moves;
    }
}