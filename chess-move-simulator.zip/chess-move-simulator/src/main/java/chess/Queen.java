package chess;

import java.util.ArrayList;
import java.util.List;

public class Queen implements ChessPiece {
    private final int[][] directions = {
        {-1, -1}, {-1, 0}, {-1, 1},
        { 0, -1},          { 0, 1},
        { 1, -1}, { 1, 0}, { 1, 1}
    };

    public List<String> getValidMoves(String posStr) {
        Position pos = Position.fromString(posStr);
        List<String> moves = new ArrayList<>();
        for (int[] dir : directions) {
            int newRow = pos.row + dir[0];
            int newCol = pos.col + dir[1];
            while (Position.isValid(newRow, newCol)) {
                moves.add(new Position(newRow, newCol).toString());
                newRow += dir[0];
                newCol += dir[1];
            }
        }
        return moves;
    }
}