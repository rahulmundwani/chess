package chess;

import java.util.List;

public interface ChessPiece {
    List<String> getValidMoves(String position);
}